package application;

import java.util.ArrayList;

public class Admin {

	private String userName;
	private String password;
	
	public Admin() {
		this.userName= "admin";
		this.password="12345";
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
}
